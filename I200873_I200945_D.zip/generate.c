#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {



	long int count = 0;

    printf("Enter the size of matrix : ");
    scanf("%ld", &count);
	
    srand(time(0));
    int Matrix_M[count][count] ;
    int Matrix_N[count][count] ; 
    int num = 0;
    
    
    //--------------------------------------------------------------

    //Exporting data to M.txt for M matrix
    FILE *output_file = fopen("M.txt", "w");
    if (output_file == NULL)
     {
        printf("Error opening output file.\n");
        return 1;
     }

    for (long int i = 1; i <= count; i++) 
    {
    	for(long int j = 1; j <= count; j++) 
    	{ 
        	num = rand() % 10;    
	        fprintf(output_file, "%s,%ld,%ld,%d\n","M",i,j, num);
            Matrix_M[i][j]  = num; 
        }
    }
    fclose(output_file);
    //--------------------------------------------------------------


     //Exporting data to N.txt for N matrix
    FILE *output_file2 = fopen("N.txt", "w");
    if (output_file2 == NULL) {
        printf("Error opening output file.\n");
        return 1;
    }
     num = 0;
    
    for ( int i = 1; i <= count; i++) 
    {
    	for( int j = 1; j <= count; j++) 
    	{ 
        	num = rand() % 10; 
	        fprintf(output_file2, "%s,%d,%d,%d\n","N",j,i, num);
                    Matrix_N[i][j]=num;
        }
    }


    fclose(output_file2);
    //--------------------------------------------------------------


int i=0;
int j=0;
int k=0;


//MATRIX MULTIPLICATION USING SIMPLE METHOD: 

  

    printf("\n\n-------------------------------------------\n\n\n");
    int Res_Matrix[count][count];
    for ( i= 1 ;i <=count ;i++)
    {
        for (j = 1 ;j<= count ; j++)
        {
            Res_Matrix[i][j] = 0;
            for ( k = 1 ;k <=count ; k++ )
                Res_Matrix[i][j] += Matrix_M[i][k] * Matrix_N[k][j]  ;
        }

    }

  FILE *simple_output = fopen("Simple_output.txt", "w");
    if (simple_output == NULL) {
        printf("Error opening output file.\n");
        return 1;
    }
//-----------------------------------------------------------------------

//CALCULATING THE RESULATANT MATRIX AND STORING IN SIMPLE_OUTPUT.TXT


    printf("\n\nResultant Matrix : \n\n");

     for ( i= 1 ;i <=count ;i++)
    {
        for (j = 1;j<=count ; j++)
        {
                printf(" %d ",Res_Matrix[i][j]);
                fprintf(simple_output,"(%d,%d) -> (%d) \n",i,j,Res_Matrix[i][j]);
        }
        printf("\n");    
    }


//-----------------------------------------------------------------------






    return 0;
}
